## Bin

This folder is for optional user packages and will not be automatically injected into the PATH.

Use `%lib_path% enhance_path "%cmder_root%\[path to folder]"` in `%cmder_root%\config\user_profile.cmd` or `%cmder_root%\config\profile.d\*.cmd` to add to the path.
